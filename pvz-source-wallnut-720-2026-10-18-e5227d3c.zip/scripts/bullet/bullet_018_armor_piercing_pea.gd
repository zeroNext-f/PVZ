## 重做的破甲豌豆：命中后在敌人身后一格的上下邻行各发射两颗不再分裂的破甲豌豆。
extends BulletLinear000Base
class_name Bullet018ArmorPiercingPea

## 临时发射点脚本；由独立节点发射，避免原弹命中删除后丢失分裂任务。
const SPLIT_EMITTER_SCRIPT: Script = preload("res://scripts/bullet/component/armor_pea_split_emitter.gd")
## 原弹允许分裂；发射点生成的子弹在入树前关闭此标记，最多分裂一代。
@export var can_split: bool = true
## 命中结算锁，在扣血和安排分裂之前置位，防止多个受击框重复触发。
var _hit_resolved: bool = false


## [param enemy] 为命中目标，空值表示撞地；沿用普通豌豆伤害、命中特效和单次命中销毁流程。
func attack_once(enemy: Character000Base):
	if is_queued_for_deletion() or _hit_resolved:
		return
	if enemy != null and not _can_attack_character(enemy):
		return
	_hit_resolved = true
	if enemy != null and can_split:
		_create_split_emitters(enemy)
	super(enemy)


## 按命中瞬间的 [param enemy] 位置和朝向安排发射点，不依赖目标受伤后是否仍存活。[br]
## 身后一格使用当前场地的实际列间距，邻行只取现有行，不占用植物格子，也不要求格子空闲。
func _create_split_emitters(enemy: Character000Base) -> void:
	if not is_instance_valid(Global.main_game):
		return
	# 子弹和临时发射点统一挂在原弹所在容器，坐标转换保持一致。
	var bullet_parent: Node2D = get_parent() as Node2D
	var rows: Array[ZombieRow] = Global.main_game.zombie_manager.all_zombie_rows
	var cells: Array[Array] = Global.main_game.plant_cell_manager.all_plant_cells
	# 僵王未使用普通行号时，以本次子弹所在行作为邻行参考。
	var source_lane: int = enemy.lane if enemy.lane >= 0 else lane
	if bullet_parent == null or bullet_parent.is_queued_for_deletion() \
		or source_lane < 0 or source_lane >= rows.size() or source_lane >= cells.size() \
		or cells[source_lane].is_empty():
		return
	# 当前行的实际列间距；单列场景退回使用格子在世界坐标中的宽度。
	var first_cell: PlantCell = cells[source_lane][0] as PlantCell
	# PlantCell 继承 Control，必须通过 CanvasItem 方法获取世界变换，不能读取 Node2D 专属属性。
	var column_pitch: float = first_cell.size.x * first_cell.get_global_transform().x.length()
	if cells[source_lane].size() > 1:
		column_pitch = absf(cells[source_lane][1].global_position.x - first_cell.global_position.x)
	# 普通僵尸默认向左行走，其身后为右侧；反向僵尸使用相反侧。
	var behind_direction: float = float(enemy.direction_x_root)
	var spawn_x: float = enemy.global_position.x + column_pitch * behind_direction
	# 屋顶在不同横坐标的高度差，不改变子弹原本相对于当前行的飞行高度。
	var slope_offset: float = 0.0
	if is_instance_valid(Global.main_game.main_game_slope):
		slope_offset = Global.main_game.main_game_slope.get_all_slope_y(spawn_x) \
			- Global.main_game.main_game_slope.get_all_slope_y(global_position.x)
	# 只遍历上下两行，地图边缘不越界、不折返到当前行。
	for lane_offset: int in [-1, 1]:
		# 本临时发射点所在行以及该行相对于命中行的垂直偏移。
		var destination_lane: int = source_lane + lane_offset
		if destination_lane < 0 or destination_lane >= rows.size():
			continue
		var row_offset: float = rows[destination_lane].zombie_create_position.global_position.y \
			- rows[source_lane].zombie_create_position.global_position.y
		# 复制原弹方向、阵营和受击状态筛选，发射点脚本仅覆盖出生位置和关闭子弹分裂。
		var emitter = SPLIT_EMITTER_SCRIPT.new()
		emitter.name = "ArmorPeaSplitEmitter"
		emitter.position = bullet_parent.to_local(Vector2(spawn_x, global_position.y + row_offset + slope_offset))
		emitter.shot_parameters = get_bullet_paras()
		emitter.shot_parameters[E_InitParasAttr.BulletLane] = destination_lane
		emitter.shot_camp = bullet_camp
		# 碰撞回调中不直接添加新的碰撞区域，由原弹父容器在安全时机接收发射点。
		bullet_parent.call_deferred("add_child", emitter)
