## 破甲豌豆的一次性临时发射点：立即生成两颗不再分裂的同类子弹，然后清除自身。
extends Node2D

## 每个发射点同时发射的子弹数量，不使用额外射击计时器。
const SHOT_COUNT: int = 2
## 原弹复制的行号、方向与受击状态等初始化参数；出生位置在发射时按当前容器换算。
var shot_parameters: Dictionary = {}
## 原弹所属阵营，分裂不能改变敌我关系。
var shot_camp: CharacterRegistry.CharacterType = CharacterRegistry.CharacterType.Plant


## 入树后立即排队发射，避开父容器仍在添加节点时再次操作其子节点。
func _ready() -> void:
	call_deferred("_fire")


## 同时创建两颗同类子弹；子弹挂在独立容器下，发射点删除不影响已经发出的子弹。
func _fire() -> void:
	# 原弹所在子弹容器；场景已经退出或正在删除时不继续生成。
	var bullet_parent: Node2D = get_parent() as Node2D
	if bullet_parent == null or bullet_parent.is_queued_for_deletion():
		queue_free()
		return
	# 每次生成一颗完整的破甲豌豆实例，所有子弹在同一轮发射事件中入树。
	for _shot_index: int in range(SHOT_COUNT):
		# 独立子弹入树前关闭分裂，避免命中后继续产生后代。
		var bullet: Bullet000NormBase = Global.bullet_registry.get_bullet_scenes(
			BulletRegistry.BulletType.Bullet018ArmorPiercingPea).instantiate() as Bullet000NormBase
		bullet.set("can_split", false)
		bullet.bullet_camp = shot_camp
		# 每颗子弹拥有独立参数，位置相对于最终子弹容器，不能相对于将删除的发射点。
		var parameters: Dictionary = shot_parameters.duplicate()
		parameters[Bullet000NormBase.E_InitParasAttr.Position] = bullet_parent.to_local(global_position)
		bullet.init_bullet(parameters)
		bullet_parent.add_child(bullet)
		SoundManager.play_character_SFX(&"Throw")
	queue_free()
